
// Fix: Removed incorrect import of 'ChatSession as GeminiChatSessionSDK'. Chat config is GenerationConfig.
import { GoogleGenAI, Chat, GenerateContentResponse, Part, SafetySetting as GeminiSafetySettingFromSDK, Content, Tool, GenerateContentParameters, GenerationConfig as GeminiGenerationConfigSDK, FileData } from "@google/genai"; // Use SDK's SafetySetting type
import { ChatMessage, ChatMessageRole, GeminiSettings, GeminiHistoryEntry, SafetySetting, HarmCategory, HarmBlockThreshold, GroundingChunk, Attachment, ApiRequestLog, ApiRequestPayload, AICharacter, LoggedGeminiGenerationConfig, FileUploadResult, GeminiFileResource, AttachmentUploadState } from '../types';

const API_KEY_ENV = process.env.API_KEY;

const getApiKey = (): string | null => {
  if (!API_KEY_ENV) {
    console.error("API_KEY for Gemini is not set or accessible in environment variables.");
    return null;
  }
  return API_KEY_ENV;
}

let aiInstance: GoogleGenAI | null = null;
const getAiInstance = (): GoogleGenAI | null => {
    const apiKey = getApiKey();
    if (!apiKey) return null;
    if (!aiInstance) {
        aiInstance = new GoogleGenAI({ apiKey });
    }
    return aiInstance;
}

const activeChatInstances = new Map<string, Chat>();

// NOTE ON ATTACHMENT HANDLING FOR API:
// When constructing 'parts' for the Gemini API (e.g., in mapMessagesToGeminiHistoryInternal):
// 1. If an attachment has a 'fileUri' (from successful File API upload), a 'fileData' part is created. This sends a reference to the raw file already on Google's servers.
// 2. If 'fileUri' is not available but 'base64Data' is (e.g., as a fallback or older data), an 'inlineData' part is created. This sends the file content base64 encoded.
// 3. The 'dataUrl' field on an Attachment object is primarily for client-side UI previews (e.g., in MessageItem or ChatView's selected files tray) and is NOT directly used for API communication with Gemini models.

function mapMessagesToGeminiHistoryInternal(
  messages: ChatMessage[],
  settings?: GeminiSettings
): GeminiHistoryEntry[] {
  let eligibleMessages = messages.filter(
    msg => msg.role === ChatMessageRole.USER || msg.role === ChatMessageRole.MODEL
  );

  const maxMessages = settings?.contextWindowMessages;

  if (typeof maxMessages === 'number' && maxMessages > 0 && eligibleMessages.length > maxMessages) {
    eligibleMessages = eligibleMessages.slice(-maxMessages);
  }

  return eligibleMessages.map(msg => {
    const parts: Part[] = []; // Use SDK Part type
    let baseContent = msg.content;

    if (settings?.aiSeesTimestamps && msg.role === ChatMessageRole.USER) {
        baseContent = `[USER at ${new Date(msg.timestamp).toLocaleString()}] ${baseContent}`;
    } else if (settings?.aiSeesTimestamps && msg.role === ChatMessageRole.MODEL) {
        baseContent = `[AI at ${new Date(msg.timestamp).toLocaleString()}] ${baseContent}`;
    }
    
    if (baseContent.trim()) {
      parts.push({ text: baseContent });
    }
    
    if (msg.attachments) {
      msg.attachments.forEach(att => {
        if (att.fileUri && att.uploadState === 'completed_cloud_upload') {
          parts.push({
            fileData: { // This structure creates a FileDataPart
              mimeType: att.mimeType,
              fileUri: att.fileUri,
            }
          });
        } else if (att.base64Data && !att.error) { // Fallback to inlineData
          parts.push({ // This structure creates an InlineDataPart
            inlineData: {
              mimeType: att.mimeType,
              data: att.base64Data,
            }
          });
        }
      });
    }
    
    if (parts.length === 0 && (msg.role === ChatMessageRole.USER || msg.role === ChatMessageRole.MODEL)) { 
      parts.push({ text: "" }); 
    }
    
    return {
      role: msg.role as 'user' | 'model',
      parts: parts,
    };
  });
}

export function mapMessagesToFlippedRoleGeminiHistory(
  messages: ChatMessage[],
  settings?: GeminiSettings
): GeminiHistoryEntry[] {
  let eligibleMessages = messages.filter(
    msg => msg.role === ChatMessageRole.USER || msg.role === ChatMessageRole.MODEL || msg.role === ChatMessageRole.ERROR
  );

  const maxMessages = settings?.contextWindowMessages;

  if (typeof maxMessages === 'number' && maxMessages > 0 && eligibleMessages.length > maxMessages) {
    eligibleMessages = eligibleMessages.slice(-maxMessages);
  }

  return eligibleMessages.map(msg => {
    const parts: Part[] = []; // Use SDK Part type
    let baseContent = msg.content;
    // Timestamps are generally not flipped in role, but added if the original message had it conceptually.
    // For simplicity here, not adding timestamps to flipped roles unless specifically required.

    if (baseContent.trim()) {
      parts.push({ text: baseContent });
    }
    
    if (msg.attachments) {
      msg.attachments.forEach(att => {
        if (att.fileUri && att.uploadState === 'completed_cloud_upload') {
          parts.push({
            fileData: {
              mimeType: att.mimeType,
              fileUri: att.fileUri,
            }
          });
        } else if (att.base64Data && !att.error) {
          parts.push({
            inlineData: {
              mimeType: att.mimeType,
              data: att.base64Data,
            }
          });
        }
      });
    }
    
    let finalRole: 'user' | 'model';
    if (msg.role === ChatMessageRole.USER) {
      finalRole = 'model';
    } else { // MODEL or ERROR
      finalRole = 'user';
    }
    
    if (parts.length === 0) { 
      parts.push({ text: "" }); 
    }
    
    return {
      role: finalRole,
      parts: parts,
    };
  });
}


export function mapMessagesToCharacterPerspectiveHistory(
  allMessages: ChatMessage[],
  currentCharacterId: string,
  aiCharacters: AICharacter[],
  settings?: GeminiSettings
): GeminiHistoryEntry[] {
  const perspectiveHistory: GeminiHistoryEntry[] = [];
  const currentCharacter = aiCharacters.find(c => c.id === currentCharacterId);
  if (!currentCharacter) return [];

  let eligibleMessages = allMessages.filter(
    msg => msg.role === ChatMessageRole.USER || msg.role === ChatMessageRole.MODEL
  );
  const maxMessages = settings?.contextWindowMessages;
  if (typeof maxMessages === 'number' && maxMessages > 0 && eligibleMessages.length > maxMessages) {
    eligibleMessages = eligibleMessages.slice(-maxMessages);
  }

  for (const msg of eligibleMessages) {
    const isMsgFromCurrentCharacter = msg.role === ChatMessageRole.MODEL && msg.characterName === currentCharacter.name;
    const isMsgFromOtherCharacter = msg.role === ChatMessageRole.MODEL && msg.characterName && msg.characterName !== currentCharacter.name;
    
    let roleForThisMessage: 'user' | 'model';
    let contentForThisMessage = msg.content;

    if (settings?.aiSeesTimestamps) {
        contentForThisMessage = `[${isMsgFromCurrentCharacter ? 'SELF' : (msg.characterName || 'USER')} at ${new Date(msg.timestamp).toLocaleString()}] ${contentForThisMessage}`;
    }
    
    if (isMsgFromCurrentCharacter) {
      roleForThisMessage = 'model';
    } else { 
      roleForThisMessage = 'user';
      if (isMsgFromOtherCharacter) {
        contentForThisMessage = `${msg.characterName?.toUpperCase()}: ${contentForThisMessage}`;
      }
    }

    const messageAPIParts: Part[] = []; // Use SDK Part type
    if (contentForThisMessage.trim()) {
      messageAPIParts.push({ text: contentForThisMessage });
    }
    if (msg.attachments) {
      msg.attachments.forEach(att => {
        if (att.fileUri && att.uploadState === 'completed_cloud_upload') {
          messageAPIParts.push({
            fileData: {
              mimeType: att.mimeType,
              fileUri: att.fileUri,
            }
          });
        } else if (att.base64Data && !att.error) {
          messageAPIParts.push({
            inlineData: {
              mimeType: att.mimeType,
              data: att.base64Data,
            }
          });
        }
      });
    }
    
    if (messageAPIParts.length === 0) {
        messageAPIParts.push({ text: "" }); 
    }

    perspectiveHistory.push({ role: roleForThisMessage, parts: messageAPIParts });
  }
  
  return perspectiveHistory;
}

const POLLING_INTERVAL_MS = 2000; // 2 seconds
const MAX_POLLING_ATTEMPTS = 30; // Max 60 seconds of polling

async function pollFileStateUntilActive(
    ai: GoogleGenAI, 
    fileApiName: string, 
    logApiRequestCallback: LogApiRequestCallback,
    onStateChangeForPolling?: (state: AttachmentUploadState, message?: string) => void
): Promise<GeminiFileResource> {
    let attempts = 0;
    onStateChangeForPolling?.('processing_on_server', `Server processing file...`);
    while (attempts < MAX_POLLING_ATTEMPTS) {
        attempts++;
        try {
            if (logApiRequestCallback) {
                logApiRequestCallback({
                    requestType: 'files.getFile',
                    payload: { fileName: fileApiName }
                });
            }
            const fileResource = await ai.files.get({ name: fileApiName }) as GeminiFileResource;
            if (logApiRequestCallback && fileResource) {
                 logApiRequestCallback({
                    requestType: 'files.getFile', // Log response associated with getFile
                    payload: { fileName: fileApiName, fileApiResponse: fileResource }
                });
            }

            if (fileResource.state === 'ACTIVE') {
                onStateChangeForPolling?.('completed_cloud_upload', 'File ready on cloud.');
                return fileResource;
            }
            if (fileResource.state === 'FAILED') {
                const errorMsg = fileResource.error?.message || 'File processing failed on server.';
                onStateChangeForPolling?.('error_cloud_upload', `Error: ${errorMsg}`);
                throw new Error(errorMsg);
            }
            // Still PROCESSING, wait and poll again
            await new Promise(resolve => setTimeout(resolve, POLLING_INTERVAL_MS));
        } catch (error: any) {
            console.error(`Polling error for ${fileApiName}, attempt ${attempts}:`, error);
            onStateChangeForPolling?.('error_cloud_upload', `Polling failed: ${error.message || 'Unknown error'}`);
            throw error; // Rethrow to stop polling on significant errors
        }
    }
    onStateChangeForPolling?.('error_cloud_upload', 'File processing timed out on server.');
    throw new Error('File processing timed out after multiple polling attempts.');
}


export async function uploadFileViaApi(
  fileToUpload: globalThis.File, // Use the global File type
  logApiRequestCallback: LogApiRequestCallback,
  onStateChange?: (state: AttachmentUploadState, fileApiName?: string, message?: string, progress?: number) => void
): Promise<FileUploadResult> {
  // IMPORTANT: This function sends the raw 'fileToUpload' to the Gemini File API.
  // Any client-side generation of 'dataUrl' or 'base64Data' (e.g., in ChatView.tsx)
  // is for UI preview purposes ONLY and is NOT used by this upload function for API communication.
  const ai = getAiInstance();
  if (!ai) {
    const errorMsg = "API Key not configured for File API.";
    onStateChange?.('error_cloud_upload', undefined, errorMsg);
    return { mimeType: fileToUpload.type, originalFileName: fileToUpload.name, size: fileToUpload.size, error: errorMsg };
  }

  try {
    onStateChange?.('uploading_to_cloud', undefined, 'Uploading to cloud...');
    
    if (logApiRequestCallback) {
        logApiRequestCallback({
            requestType: 'files.uploadFile',
            payload: { file: { name: fileToUpload.name, type: fileToUpload.type, size: fileToUpload.size } }
        });
    }

    const initialFileResource = await ai.files.upload({
        file: fileToUpload,
        // name: `your-desired-resource-name/${fileToUpload.name}` // Optional: if you need to control the resource name
        // mimeType is inferred by the SDK from the File object (fileToUpload.type)
    }) as GeminiFileResource;

    if (logApiRequestCallback && initialFileResource) {
        logApiRequestCallback({
            requestType: 'files.uploadFile', // Log response associated with uploadFile
            payload: { file: { name: fileToUpload.name, type: fileToUpload.type, size: fileToUpload.size }, fileApiResponse: initialFileResource }
        });
    }


    if (initialFileResource.state === 'ACTIVE') {
      onStateChange?.('completed_cloud_upload', initialFileResource.name, 'Cloud upload complete.', 100);
      return {
        fileUri: initialFileResource.uri,
        fileApiName: initialFileResource.name,
        mimeType: initialFileResource.mimeType || fileToUpload.type,
        originalFileName: initialFileResource.displayName || fileToUpload.name,
        size: parseInt(initialFileResource.sizeBytes || String(fileToUpload.size), 10),
      };
    } else if (initialFileResource.state === 'PROCESSING') {
      const finalFileResource = await pollFileStateUntilActive(ai, initialFileResource.name, logApiRequestCallback, (state, message) => onStateChange?.(state, initialFileResource.name, message));
      return {
        fileUri: finalFileResource.uri,
        fileApiName: finalFileResource.name,
        mimeType: finalFileResource.mimeType || fileToUpload.type,
        originalFileName: finalFileResource.displayName || fileToUpload.name,
        size: parseInt(finalFileResource.sizeBytes || String(fileToUpload.size), 10),
      };
    } else if (initialFileResource.state === 'FAILED') {
        const errorMsg = initialFileResource.error?.message || 'File upload failed on server immediately.';
        onStateChange?.('error_cloud_upload', initialFileResource.name, `Error: ${errorMsg}`);
        return { mimeType: fileToUpload.type, originalFileName: fileToUpload.name, size: fileToUpload.size, error: errorMsg };
    } else {
        const errorMsg = `Unexpected file state after upload: ${initialFileResource.state}`;
        onStateChange?.('error_cloud_upload', initialFileResource.name, errorMsg);
        return { mimeType: fileToUpload.type, originalFileName: fileToUpload.name, size: fileToUpload.size, error: errorMsg };
    }
  } catch (error: any) {
    console.error("File API upload error:", error);
    const errorMsg = error.message || "An unknown error occurred during file upload.";
    onStateChange?.('error_cloud_upload', undefined, `Error: ${errorMsg}`);
    return { mimeType: fileToUpload.type, originalFileName: fileToUpload.name, size: fileToUpload.size, error: errorMsg };
  }
}

export async function deleteFileViaApi(
  fileApiName: string,
  logApiRequestCallback: LogApiRequestCallback
): Promise<void> {
  const ai = getAiInstance();
  if (!ai) {
    throw new Error("API Key not configured for File API.");
  }

  try {
    if (logApiRequestCallback) {
      logApiRequestCallback({
        requestType: 'files.delete',
        payload: { fileName: fileApiName }
      });
    }
    await ai.files.delete({ name: fileApiName });
    // Log success? SDK does not return a body for successful delete.
  } catch (error: any) {
    console.error(`File API delete error for ${fileApiName}:`, error);
    // Log error response if available
    if (logApiRequestCallback) {
      logApiRequestCallback({
        requestType: 'files.delete',
        payload: { fileName: fileApiName, fileApiResponse: { error: error.message || String(error) } }
      });
    }
    throw error; // Rethrow to be handled by caller
  }
}


export function clearCachedChat(sessionId: string, model: string, settings: GeminiSettings): void {
  const sortedSettings = settings ? JSON.parse(JSON.stringify(settings, Object.keys(settings).sort())) : {};
  const characterIdForCacheKey = (settings as any)._characterIdForCacheKey;

  const cacheKeyForSDKInstance = characterIdForCacheKey
    ? `${sessionId}_char_${characterIdForCacheKey}-${model}-${JSON.stringify(sortedSettings)}`
    : `${sessionId}-${model}-${JSON.stringify(sortedSettings)}`;
  
  if (activeChatInstances.has(cacheKeyForSDKInstance)) {
    activeChatInstances.delete(cacheKeyForSDKInstance);
     console.log(`[GeminiService] Cleared cached chat instance for key: ${cacheKeyForSDKInstance}`);
  }
}

export interface FullResponseData {
    text: string;
    groundingMetadata?: { groundingChunks?: GroundingChunk[] };
}

export interface UserMessageInput {
    text: string;
    attachments?: Attachment[]; 
}

export type LogApiRequestCallback = (logDetails: Omit<ApiRequestLog, 'id' | 'timestamp'>) => void;


export async function getFullChatResponse( 
  sessionId: string, 
  userMessageInput: UserMessageInput,
  model: string,
  baseSettings: GeminiSettings, 
  currentChatMessages: ChatMessage[], 
  onFullResponse: (data: FullResponseData) => void, 
  onError: (error: string, isAbortError?: boolean) => void,
  onComplete: () => void,
  logApiRequestCallback: LogApiRequestCallback,
  signal?: AbortSignal,
  settingsOverride?: Partial<GeminiSettings & { _characterIdForAPICall?: string }>, 
  allAiCharactersInSession?: AICharacter[]
): Promise<void> {
  const ai = getAiInstance();
  if (!ai) {
    onError("API Key is not configured. Please set the API_KEY environment variable.", false);
    onComplete();
    return;
  }

  if (signal?.aborted) {
    onError("Request aborted by user before sending.", true);
    onComplete();
    return;
  }

  const combinedSettings = { ...baseSettings, ...settingsOverride }; 
  const characterIdForAPICall = (settingsOverride as any)?._characterIdForAPICall;

  const characterForCall = characterIdForAPICall && allAiCharactersInSession
    ? allAiCharactersInSession.find(c => c.id === characterIdForAPICall)
    : undefined;
  
  const isCharacterTurn = !!characterForCall;
  const characterNameForLogging = characterForCall ? characterForCall.name : undefined;
  const characterIdForCacheKey = characterForCall ? characterForCall.id : undefined;


  const messageParts: Part[] = []; // Use SDK Part type
  let effectiveUserText = userMessageInput.text;

  if (combinedSettings.aiSeesTimestamps) {
      const formattedTimestamp = new Date().toLocaleString(); 
      effectiveUserText = `[USER at ${formattedTimestamp}] ${effectiveUserText}`;
  }
  if (combinedSettings.urlContext && combinedSettings.urlContext.length > 0 && userMessageInput.text.trim()) {
    const urlContextString = `\n\nProvided URL Context:\n${combinedSettings.urlContext.map(url => `- ${url}`).join('\n')}`;
    effectiveUserText = `${effectiveUserText}${urlContextString}`;
  }
  
  let textPartAdded = false;
  if (effectiveUserText.trim()) {
    messageParts.push({ text: effectiveUserText });
    textPartAdded = true;
  }

  if (userMessageInput.attachments) {
    userMessageInput.attachments.forEach(att => {
        if (att.fileUri && att.uploadState === 'completed_cloud_upload') {
          messageParts.push({ fileData: { mimeType: att.mimeType, fileUri: att.fileUri } });
        } else if (att.base64Data && !att.error) { // Fallback to inlineData
          messageParts.push({ inlineData: { mimeType: att.mimeType, data: att.base64Data } });
        }
    });
  }
  
  // Ensure a text part exists if other parts (like fileData) are present, and no text was initially added.
  if (!textPartAdded && messageParts.length > 0) {
    messageParts.unshift({ text: "" }); 
  }

  if (messageParts.length === 0) { 
      // This check ensures we don't send an entirely empty message (no text, no valid attachments)
      // This logic path should ideally be caught by `useGemini` before calling this function.
      const hasValidAttachments = userMessageInput.attachments && userMessageInput.attachments.some(att => (att.fileUri && att.uploadState === 'completed_cloud_upload') || (att.base64Data && !att.error));
      if (!effectiveUserText.trim() && !hasValidAttachments) {
          onError("Cannot send an empty message with no valid attachments.", false);
          onComplete();
          return;
      }
      // If somehow messageParts is still empty (e.g. text was whitespace, all attachments invalid), add a default empty text part.
      // This is a final safeguard, as the above `unshift` should handle most cases for attachment-only messages.
      if(messageParts.length === 0) {
        messageParts.push({ text: "" });
      }
  }
  
  let effectiveSettingsForCacheKeyConstruction = { ...combinedSettings };
  if (characterIdForCacheKey && characterForCall) {
      effectiveSettingsForCacheKeyConstruction.systemInstruction = characterForCall.systemInstruction; 
      (effectiveSettingsForCacheKeyConstruction as any)._characterIdForCacheKey = characterIdForCacheKey;
      delete (effectiveSettingsForCacheKeyConstruction as any)._characterIdForAPICall;
  } else {
      delete (effectiveSettingsForCacheKeyConstruction as any)._characterIdForCacheKey;
      delete (effectiveSettingsForCacheKeyConstruction as any)._characterIdForAPICall;
  }
  const sortedSettingsForCacheKey = JSON.parse(JSON.stringify(effectiveSettingsForCacheKeyConstruction, Object.keys(effectiveSettingsForCacheKeyConstruction).sort()));

  const cacheKeyForSDKInstance = characterIdForCacheKey
      ? `${sessionId}_char_${characterIdForCacheKey}-${model}-${JSON.stringify(sortedSettingsForCacheKey)}`
      : `${sessionId}-${model}-${JSON.stringify(sortedSettingsForCacheKey)}`;

  let historyForChatInitialization: GeminiHistoryEntry[];
  if (isCharacterTurn && characterForCall && allAiCharactersInSession) {
    historyForChatInitialization = mapMessagesToCharacterPerspectiveHistory(currentChatMessages, characterForCall.id, allAiCharactersInSession, combinedSettings);
  } else {
    historyForChatInitialization = mapMessagesToGeminiHistoryInternal(currentChatMessages, combinedSettings);
  }

  const configForChatCreate: any = {}; 
  let finalSystemInstructionText: string | undefined = undefined;

  if (characterForCall && characterForCall.systemInstruction) { // Character-specific system instruction
      finalSystemInstructionText = characterForCall.systemInstruction;
  } else if (combinedSettings.systemInstruction) { // General system instruction
      finalSystemInstructionText = combinedSettings.systemInstruction;
  }


  if (finalSystemInstructionText) {
    configForChatCreate.systemInstruction = { role: "system", parts: [{text: finalSystemInstructionText }] };
  }

  if (combinedSettings.temperature !== undefined) configForChatCreate.temperature = combinedSettings.temperature;
  if (combinedSettings.topP !== undefined) configForChatCreate.topP = combinedSettings.topP;
  if (combinedSettings.topK !== undefined) configForChatCreate.topK = combinedSettings.topK;
  if (combinedSettings.safetySettings) {
    configForChatCreate.safetySettings = combinedSettings.safetySettings.map(s => ({
        category: s.category,
        threshold: s.threshold,
    })) as GeminiSafetySettingFromSDK[];
  }
  if (combinedSettings.useGoogleSearch) {
    configForChatCreate.tools = [{googleSearch: {}}];
  }

  let chatForThisMessage: Chat;
  
  try {
    if (combinedSettings.debugApiRequests) {
      logApiRequestCallback({
        requestType: 'chat.create',
        payload: {
          model: model,
          history: historyForChatInitialization, 
          config: configForChatCreate as Partial<LoggedGeminiGenerationConfig> 
        },
        characterName: characterNameForLogging,
        apiSessionId: cacheKeyForSDKInstance 
      });
    }
    chatForThisMessage = ai.chats.create({
      model: model,
      history: historyForChatInitialization as Content[], // Cast GeminiHistoryEntry[] to Content[]
      config: configForChatCreate as GeminiGenerationConfigSDK, 
    });
  } catch (error: any) {
    console.error("Error creating chat session:", error, "Cache Key:", cacheKeyForSDKInstance);
    if (signal?.aborted) {
      onError(`Chat initialization aborted. Original error: ${error.message || String(error)}`, true);
    } else {
      onError(`Failed to initialize chat: ${error.message || String(error)}`, false);
    }
    onComplete();
    return;
  }
  
  try {
    if (combinedSettings.debugApiRequests) {
       logApiRequestCallback({
        requestType: 'chat.sendMessage',
        payload: {
          model: model, 
          contents: [{ role: 'user', parts: JSON.parse(JSON.stringify(messageParts)) }], // Log payload structured as Content[]
        },
        characterName: characterNameForLogging,
        apiSessionId: cacheKeyForSDKInstance 
      });
    }
    
    const response: GenerateContentResponse = await chatForThisMessage.sendMessage({ message: messageParts }); 
    
    const fullText = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    
    const responseData: FullResponseData = {
        text: (fullText !== undefined && fullText !== null) ? fullText : "",
        groundingMetadata: groundingMetadata ? { groundingChunks: groundingMetadata.groundingChunks as GroundingChunk[] } : undefined
    };
    onFullResponse(responseData);
    onComplete();
  } catch (error: any) {
    console.error("Error sending message:", error);
    let errorMessage = "Failed to get response from AI.";
    if (error.message) {
        errorMessage = error.message;
    } else if (error.response && error.response.data && error.response.data.error && error.response.data.error.message) { 
        errorMessage = error.response.data.error.message;
    } else if (typeof error === 'string') {
        errorMessage = error;
    }

    if (signal?.aborted) {
        onError(`Request aborted. Original error: ${errorMessage}`, true);
    } else {
        onError(errorMessage, false);
    }
    onComplete();
  }
}

export async function generateMimicUserResponse(
    modelId: string,
    mappedAndPotentiallyFlippedHistory: GeminiHistoryEntry[], 
    userPersonaInstructionText: string, 
    baseSettings: GeminiSettings,
    logApiRequestCallback: LogApiRequestCallback, 
    signal?: AbortSignal,
    settingsOverride?: Partial<GeminiSettings> 
): Promise<string> {
    const ai = getAiInstance();
    if (!ai) {
        throw new Error("API Key is not configured.");
    }

    if (signal?.aborted) {
        throw new Error("Request aborted by user before sending.");
    }
    
    const combinedSettings = { ...baseSettings, ...settingsOverride }; 
    
    const safetySettingsForSDK: GeminiSafetySettingFromSDK[] | undefined = combinedSettings.safetySettings
        ? combinedSettings.safetySettings.map(s => ({
            category: s.category,
            threshold: s.threshold,
          }))
        : undefined;

    const generationConfigForCall: any = {}; 
    if (combinedSettings.temperature !== undefined) generationConfigForCall.temperature = combinedSettings.temperature;
    if (combinedSettings.topP !== undefined) generationConfigForCall.topP = combinedSettings.topP;
    if (combinedSettings.topK !== undefined) generationConfigForCall.topK = combinedSettings.topK;
    
    if (userPersonaInstructionText) {
        generationConfigForCall.systemInstruction = { role: "system", parts: [{text: userPersonaInstructionText }] };
    }
    if (safetySettingsForSDK) {
        generationConfigForCall.safetySettings = safetySettingsForSDK;
    }
    
    try {
        const requestContents: Content[] = mappedAndPotentiallyFlippedHistory.map(entry => ({
            role: entry.role,
            parts: entry.parts // This is already Part[] due to GeminiHistoryEntry.parts being Part[]
        }));
        
        if (combinedSettings.debugApiRequests) {
           logApiRequestCallback({
                requestType: 'models.generateContent',
                payload: {
                    model: modelId,
                    contents: JSON.parse(JSON.stringify(requestContents)),
                    config: generationConfigForCall as Partial<LoggedGeminiGenerationConfig> 
                },
                characterName: (combinedSettings as any)._characterNameForLog || "[User Mimic Instruction Active]"
           });
        }

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: modelId,
            contents: requestContents, 
            config: generationConfigForCall as GeminiGenerationConfigSDK, 
        });
        
        if (signal?.aborted) {
             throw new Error("Request aborted during generation.");
        }
        return response.text ?? ""; 
    } catch (error: any) {
        if (signal?.aborted) {
            throw error; 
        }
        console.error("Error in generateMimicUserResponse:", error);
        const message = error.message || String(error);
        const detailedError = error.details || (error.cause ? `Cause: ${error.cause}` : '');
        throw new Error(`Failed to generate user mimic response: ${message} ${detailedError}`.trim());
    }
}
